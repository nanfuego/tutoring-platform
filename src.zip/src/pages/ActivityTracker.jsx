import { useEffect, useMemo, useState } from 'react'
import { supabase } from '../supabaseClient'
import './ActivityTracker.css'

function ActivityTracker() {
  // ============================================================
  // DATA
  // ============================================================

  const [students, setStudents] = useState([])
  const [requirements, setRequirements] = useState([])
  const [studentActivity, setStudentActivity] = useState([])

  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  // ============================================================
  // FILTERS
  // ============================================================

  const [search, setSearch] = useState('')
  const [clinicFilter, setClinicFilter] = useState('all')

  // ============================================================
  // CHECKLIST MODAL
  // ============================================================

  const [selectedStudent, setSelectedStudent] = useState(null)
  const [savingActivityId, setSavingActivityId] = useState(null)

  // ============================================================
  // MANAGE ACTIVITY MODAL
  // ============================================================

  const [showManageActivity, setShowManageActivity] =
    useState(false)

  const [showActivityForm, setShowActivityForm] =
    useState(false)

  const [editingActivity, setEditingActivity] =
    useState(null)

  const [activityForm, setActivityForm] = useState({
    name: '',
    code: '',
    week: '1',
  })

  const [savingActivity, setSavingActivity] =
    useState(false)

  // ============================================================
  // DELETE MODAL
  // ============================================================

  const [activityToDelete, setActivityToDelete] =
    useState(null)

  const [deletingActivityId, setDeletingActivityId] =
    useState(null)

  // ============================================================
  // LOAD
  // ============================================================

  useEffect(() => {
    loadData()
  }, [])

  async function loadData() {
    setLoading(true)
    setError('')

    try {
      const [
        studentsResponse,
        requirementsResponse,
        activityResponse,
      ] = await Promise.all([
        supabase
          .from('students')
          .select('*')
          .order('name', { ascending: true }),

        supabase
          .from('activity_requirements')
          .select('*')
          .order('week', {
            ascending: true,
            nullsFirst: false,
          })
          .order('sort_order', {
            ascending: true,
            nullsFirst: false,
          }),

        supabase
          .from('student_activity')
          .select('*'),
      ])

      if (studentsResponse.error) {
        throw studentsResponse.error
      }

      if (requirementsResponse.error) {
        throw requirementsResponse.error
      }

      if (activityResponse.error) {
        throw activityResponse.error
      }

      setStudents(studentsResponse.data || [])
      setRequirements(
        requirementsResponse.data || []
      )
      setStudentActivity(
        activityResponse.data || []
      )
    } catch (err) {
      console.error(
        'Student Progress loading error:',
        err
      )

      setError(
        err.message ||
          'Unable to load Student Progress.'
      )
    } finally {
      setLoading(false)
    }
  }

  // ============================================================
  // CLINICS
  // ============================================================

  const clinics = useMemo(() => {
    const values = new Set()

    students.forEach((student) => {
      if (student.clinic) {
        values.add(student.clinic)
      }
    })

    return Array.from(values).sort()
  }, [students])

  // ============================================================
  // ACTIVITY GROUPS
  // ============================================================

  const activityGroups = useMemo(() => {
    const groups = {}

    requirements.forEach((requirement) => {
      const week = requirement.week ?? 0

      if (!groups[week]) {
        groups[week] = []
      }

      groups[week].push(requirement)
    })

    return Object.entries(groups)
      .sort(
        ([a], [b]) =>
          Number(a) - Number(b)
      )
      .map(([week, items]) => ({
        week: Number(week),
        label:
          Number(week) === 0
            ? 'General'
            : `Week ${week}`,
        items,
      }))
  }, [requirements])

  // ============================================================
  // PROGRESS MAP
  // ============================================================

  const progressMap = useMemo(() => {
    const map = {}

    students.forEach((student) => {
      const completed =
        studentActivity.filter(
          (item) =>
            item.student_id ===
              student.id &&
            item.completed === true
        ).length

      map[student.id] = {
        completed,
        total: requirements.length,
        percentage:
          requirements.length > 0
            ? Math.round(
                (completed /
                  requirements.length) *
                  100
              )
            : 0,
      }
    })

    return map
  }, [
    students,
    requirements,
    studentActivity,
  ])

  // ============================================================
  // FILTERED STUDENTS
  // ============================================================

  const filteredStudents = useMemo(() => {
    const query =
      search.trim().toLowerCase()

    return students.filter((student) => {
      if (
        clinicFilter !== 'all' &&
        student.clinic !== clinicFilter
      ) {
        return false
      }

      if (!query) {
        return true
      }

      const searchable = [
        student.name,
        student.email,
        student.program,
        student.university,
        student.subject,
        student.clinic,
      ]
        .filter(Boolean)
        .join(' ')
        .toLowerCase()

      return searchable.includes(query)
    })
  }, [
    students,
    search,
    clinicFilter,
  ])

  // ============================================================
  // SUMMARY
  // ============================================================

  const totalStudents = students.length
  const totalActivities = requirements.length

  const completedItems =
    studentActivity.filter(
      (item) => item.completed === true
    ).length

  const possibleItems =
    totalStudents * totalActivities

  const overallProgress =
    possibleItems > 0
      ? Math.round(
          (completedItems /
            possibleItems) *
            100
        )
      : 0

  // ============================================================
  // HELPERS
  // ============================================================

  function getStudentActivity(
    studentId,
    requirementId
  ) {
    return studentActivity.find(
      (item) =>
        item.student_id === studentId &&
        item.requirement_id ===
          requirementId
    )
  }

  function getStatus(percentage) {
    if (percentage >= 100) {
      return 'Completed'
    }

    if (percentage > 0) {
      return 'In Progress'
    }

    return 'Not Started'
  }

  // ============================================================
  // CHECKLIST
  // ============================================================

  function openChecklist(student) {
    setSelectedStudent(student)
  }

  function closeChecklist() {
    setSelectedStudent(null)
  }

  async function toggleActivity(
    studentId,
    requirementId,
    currentCompleted
  ) {
    setSavingActivityId(requirementId)
    setError('')

    try {
      const existing =
        getStudentActivity(
          studentId,
          requirementId
        )

      if (existing) {
        const {
          data,
          error: updateError,
        } = await supabase
          .from('student_activity')
          .update({
            completed:
              !currentCompleted,
            updated_at:
              new Date().toISOString(),
          })
          .eq('id', existing.id)
          .select()
          .single()

        if (updateError) {
          throw updateError
        }

        setStudentActivity((current) =>
          current.map((item) =>
            item.id === existing.id
              ? data
              : item
          )
        )
      } else {
        const {
          data,
          error: insertError,
        } = await supabase
          .from('student_activity')
          .insert({
            student_id: studentId,
            requirement_id:
              requirementId,
            completed: true,
          })
          .select()
          .single()

        if (insertError) {
          throw insertError
        }

        setStudentActivity((current) => [
          ...current,
          data,
        ])
      }
    } catch (err) {
      console.error(
        'Activity update error:',
        err
      )

      setError(
        err.message ||
          'Unable to update activity.'
      )
    } finally {
      setSavingActivityId(null)
    }
  }

  // ============================================================
  // NOTES
  // ============================================================

  async function saveNote(
    studentId,
    requirementId,
    note
  ) {
    const existing =
      getStudentActivity(
        studentId,
        requirementId
      )

    try {
      if (existing) {
        const {
          data,
          error: updateError,
        } = await supabase
          .from('student_activity')
          .update({
            note,
            updated_at:
              new Date().toISOString(),
          })
          .eq('id', existing.id)
          .select()
          .single()

        if (updateError) {
          throw updateError
        }

        setStudentActivity((current) =>
          current.map((item) =>
            item.id === existing.id
              ? data
              : item
          )
        )
      } else if (note.trim()) {
        const {
          data,
          error: insertError,
        } = await supabase
          .from('student_activity')
          .insert({
            student_id: studentId,
            requirement_id:
              requirementId,
            completed: false,
            note,
          })
          .select()
          .single()

        if (insertError) {
          throw insertError
        }

        setStudentActivity((current) => [
          ...current,
          data,
        ])
      }
    } catch (err) {
      console.error(
        'Note save error:',
        err
      )

      setError(
        err.message ||
          'Unable to save note.'
      )
    }
  }

  // ============================================================
  // MANAGE ACTIVITY
  // ============================================================

  function openManageActivity() {
    setError('')
    setShowManageActivity(true)
    setShowActivityForm(false)
    setEditingActivity(null)
    setActivityToDelete(null)
  }

  function closeManageActivity() {
    if (
      savingActivity ||
      deletingActivityId
    ) {
      return
    }

    setShowManageActivity(false)
    setShowActivityForm(false)
    setEditingActivity(null)
    setActivityToDelete(null)

    resetActivityForm()
  }

  // ============================================================
  // ADD ACTIVITY
  // ============================================================

  function resetActivityForm() {
    setActivityForm({
      name: '',
      code: '',
      week: '1',
    })
  }

  function openAddActivity() {
    setError('')

    setEditingActivity(null)

    resetActivityForm()

    setShowActivityForm(true)
  }

  // ============================================================
  // EDIT ACTIVITY
  // ============================================================

  function openEditActivity(requirement) {
    setError('')

    setEditingActivity(requirement)

    setActivityForm({
      name:
        requirement.label || '',
      code:
        requirement.code || '',
      week:
        String(
          requirement.week ?? 1
        ),
    })

    setShowActivityForm(true)
  }

  function closeActivityForm() {
    if (savingActivity) {
      return
    }

    setShowActivityForm(false)
    setEditingActivity(null)

    resetActivityForm()
  }

  // ============================================================
  // SAVE ACTIVITY
  // ============================================================

  async function saveActivity(event) {
    event.preventDefault()

    const name =
      activityForm.name.trim()

    const code =
      activityForm.code.trim()

    const week =
      Number(activityForm.week)

    if (!name) {
      setError(
        'Please enter an activity name.'
      )
      return
    }

    if (
      !Number.isInteger(week) ||
      week < 0
    ) {
      setError(
        'Activity Week must be a valid number.'
      )
      return
    }

    setSavingActivity(true)
    setError('')

    try {
      // --------------------------------------------------------
      // EDIT
      // --------------------------------------------------------

      if (editingActivity) {
        const {
          data,
          error: updateError,
        } = await supabase
          .from('activity_requirements')
          .update({
            label: name,
            code:
              code ||
              editingActivity.code ||
              `ACT-${Date.now()}`,
            week,
          })
          .eq(
            'id',
            editingActivity.id
          )
          .select()
          .single()

        if (updateError) {
          throw updateError
        }

        setRequirements((current) =>
          current.map((item) =>
            item.id ===
            editingActivity.id
              ? data
              : item
          )
        )
      }

      // --------------------------------------------------------
      // ADD
      // --------------------------------------------------------

      else {
        const {
          data,
          error: insertError,
        } = await supabase
          .from('activity_requirements')
          .insert({
            code:
              code ||
              `ACT-${Date.now()}`,
            label: name,
            week,
            sort_order:
              requirements.length,
          })
          .select()
          .single()

        if (insertError) {
          throw insertError
        }

        setRequirements((current) => [
          ...current,
          data,
        ])
      }

      closeActivityForm()
    } catch (err) {
      console.error(
        'Save activity error:',
        err
      )

      setError(
        err.message ||
          'Unable to save activity.'
      )
    } finally {
      setSavingActivity(false)
    }
  }

  // ============================================================
  // DELETE
  // ============================================================

  function openDeleteActivity(requirement) {
    setError('')
    setActivityToDelete(requirement)
  }

  function closeDeleteActivity() {
    if (deletingActivityId) {
      return
    }

    setActivityToDelete(null)
  }

  async function confirmDeleteActivity() {
    if (!activityToDelete) {
      return
    }

    const requirement =
      activityToDelete

    setDeletingActivityId(
      requirement.id
    )

    setError('')

    try {
      // Delete checklist records first.
      const {
        error:
          checklistDeleteError,
      } = await supabase
        .from('student_activity')
        .delete()
        .eq(
          'requirement_id',
          requirement.id
        )

      if (checklistDeleteError) {
        throw checklistDeleteError
      }

      // Delete the activity.
      const {
        error:
          activityDeleteError,
      } = await supabase
        .from('activity_requirements')
        .delete()
        .eq(
          'id',
          requirement.id
        )

      if (activityDeleteError) {
        throw activityDeleteError
      }

      setRequirements((current) =>
        current.filter(
          (item) =>
            item.id !== requirement.id
        )
      )

      setStudentActivity((current) =>
        current.filter(
          (item) =>
            item.requirement_id !==
            requirement.id
        )
      )

      setActivityToDelete(null)
    } catch (err) {
      console.error(
        'Delete activity error:',
        err
      )

      setError(
        err.message ||
          'Unable to delete activity.'
      )
    } finally {
      setDeletingActivityId(null)
    }
  }

  // ============================================================
  // END SEMESTER
  // ============================================================

  function handleEndSemester() {
    window.alert(
      'Semester rollover is not connected yet. We can connect this button to the semester history tables next.'
    )
  }

  // ============================================================
  // RENDER
  // ============================================================

  return (
    <div className="activity-page">

      {/* ======================================================
          PAGE HEADER
      ======================================================= */}

      <section className="activity-page-header">

        <div className="activity-page-header-copy">

          <span className="activity-eyebrow">
            ACTIVITY MANAGEMENT
          </span>

          <h1>
            Student Progress
          </h1>

          <p>
            Monitor student activity
            and manage the current
            semester.
          </p>

        </div>

        <div className="activity-page-actions">

          <button
            type="button"
            className="activity-primary-button"
            onClick={
              openManageActivity
            }
          >
            <span className="button-plus">
              +
            </span>

            Manage Activity
          </button>

          <button
            type="button"
            className="activity-primary-button"
            onClick={
              handleEndSemester
            }
          >
            End Semester
          </button>

        </div>

      </section>


      {/* ======================================================
          ERROR
      ======================================================= */}

      {error && (
        <div className="activity-error">

          <div>

            <strong>
              Something went wrong
            </strong>

            <span>
              {error}
            </span>

          </div>

          <button
            type="button"
            onClick={() =>
              setError('')
            }
          >
            ×
          </button>

        </div>
      )}


      {/* ======================================================
          SUMMARY
      ======================================================= */}

      <section className="activity-summary-grid">

        <div className="activity-summary-card">

          <span>
            STUDENTS
          </span>

          <strong>
            {totalStudents}
          </strong>

          <small>
            Students currently being
            monitored
          </small>

        </div>


        <div className="activity-summary-card">

          <span>
            ACTIVITIES
          </span>

          <strong>
            {totalActivities}
          </strong>

          <small>
            Checklist requirements
          </small>

        </div>


        <div className="activity-summary-card">

          <span>
            COMPLETED
          </span>

          <strong>
            {completedItems}
          </strong>

          <small>
            Completed activities
          </small>

        </div>


        <div className="activity-summary-card">

          <span>
            OVERALL PROGRESS
          </span>

          <strong>
            {overallProgress}%
          </strong>

          <small>
            Across all students
          </small>

        </div>

      </section>


      {/* ======================================================
          FILTER BAR
      ======================================================= */}

      <section className="activity-filter-card">

        <div className="activity-filter-search">

          <span className="search-icon">
            ⌕
          </span>

          <input
            type="text"
            value={search}
            placeholder="Search student..."
            onChange={(event) =>
              setSearch(
                event.target.value
              )
            }
          />

          {search && (
            <button
              type="button"
              className="clear-search"
              onClick={() =>
                setSearch('')
              }
            >
              ×
            </button>
          )}

        </div>


        <select
          className="activity-filter-select"
          value={clinicFilter}
          onChange={(event) =>
            setClinicFilter(
              event.target.value
            )
          }
        >

          <option value="all">
            All Clinics
          </option>

          {clinics.map((clinic) => (
            <option
              key={clinic}
              value={clinic}
            >
              {clinic}
            </option>
          ))}

        </select>


        <div className="activity-filter-count">

          Showing{' '}

          <strong>
            {filteredStudents.length}
          </strong>

          {' '}of{' '}

          <strong>
            {students.length}
          </strong>

        </div>

      </section>


      {/* ======================================================
          STUDENTS
      ======================================================= */}

      {loading ? (

        <div className="activity-state-card">

          <div className="activity-spinner" />

          <strong>
            Loading Student Progress
          </strong>

          <span>
            Please wait while the
            student activity is loaded.
          </span>

        </div>

      ) : filteredStudents.length === 0 ? (

        <div className="activity-state-card">

          <div className="activity-state-icon">
            ?
          </div>

          <strong>
            No students found
          </strong>

          <span>
            Try changing your search
            or clinic filter.
          </span>

        </div>

      ) : (

        <section className="activity-table-card">

          <div className="activity-table-scroll">

            <table className="activity-table">

              <thead>

                <tr>

                  <th>
                    STUDENT
                  </th>

                  <th>
                    PROGRAM / SCHOOL
                  </th>

                  <th>
                    ACTIVITY PROGRESS
                  </th>

                  <th>
                    STATUS
                  </th>

                  <th className="activity-action-column">
                    ACTION
                  </th>

                </tr>

              </thead>


              <tbody>

                {filteredStudents.map(
                  (student) => {

                    const progress =
                      progressMap[
                        student.id
                      ] || {
                        completed: 0,
                        total:
                          totalActivities,
                        percentage: 0,
                      }

                    const status =
                      getStatus(
                        progress.percentage
                      )

                    return (

                      <tr
                        key={
                          student.id
                        }
                      >

                        {/* STUDENT */}

                        <td>

                          <div className="student-person">

                            <div className="student-avatar">

                              {student.name
                                ?.charAt(
                                  0
                                )
                                ?.toUpperCase() ||
                                '?'}

                            </div>

                            <div className="student-person-info">

                              <strong>
                                {
                                  student.name
                                }
                              </strong>

                              {student.email && (
                                <span>
                                  {
                                    student.email
                                  }
                                </span>
                              )}

                            </div>

                          </div>

                        </td>


                        {/* PROGRAM */}

                        <td>

                          <div className="program-school">

                            <strong>
                              {
                                student.program ||
                                'General'
                              }
                            </strong>

                            <span>
                              {
                                student.university ||
                                student.clinic ||
                                '—'
                              }
                            </span>

                          </div>

                        </td>


                        {/* PROGRESS */}

                        <td>

                          <div className="progress-cell">

                            <div className="progress-track">

                              <div
                                className="progress-fill"
                                style={{
                                  width: `${progress.percentage}%`,
                                }}
                              />

                            </div>

                            <strong>
                              {
                                progress.percentage
                              }%
                            </strong>

                            <span>
                              {
                                progress.completed
                              }/
                              {
                                progress.total
                              }
                            </span>

                          </div>

                        </td>


                        {/* STATUS */}

                        <td>

                          <span
                            className={`progress-status status-${status
                              .toLowerCase()
                              .replace(
                                ' ',
                                '-'
                              )}`}
                          >

                            <span className="status-dot" />

                            {status}

                          </span>

                        </td>


                        {/* ACTION */}

                        <td className="activity-action-column">

                          <button
                            type="button"
                            className="view-checklist-button"
                            onClick={() =>
                              openChecklist(
                                student
                              )
                            }
                          >
                            View Checklist

                            <span>
                              →
                            </span>

                          </button>

                        </td>

                      </tr>

                    )
                  }
                )}

              </tbody>

            </table>

          </div>

        </section>

      )}


      {/* ======================================================
          STUDENT CHECKLIST MODAL
      ======================================================= */}

      {selectedStudent && (

        <div
          className="activity-modal-overlay"
          onMouseDown={(event) => {
            if (
              event.target ===
              event.currentTarget
            ) {
              closeChecklist()
            }
          }}
        >

          <div
            className="checklist-modal"
            onMouseDown={(event) =>
              event.stopPropagation()
            }
          >

            <div className="modal-header">

              <div>

                <span className="activity-eyebrow">
                  STUDENT ACTIVITY
                </span>

                <h2>
                  {
                    selectedStudent.name
                  }
                </h2>

                <p>

                  {
                    selectedStudent.program ||
                    'General'
                  }

                  {selectedStudent.university &&
                    ` · ${selectedStudent.university}`}

                </p>

              </div>


              <button
                type="button"
                className="modal-close"
                onClick={
                  closeChecklist
                }
              >
                ×
              </button>

            </div>


            {/* PROGRESS */}

            <div className="checklist-summary">

              <div className="checklist-summary-top">

                <span>
                  OVERALL COMPLETION
                </span>

                <strong>
                  {
                    progressMap[
                      selectedStudent.id
                    ]?.percentage || 0
                  }%
                </strong>

              </div>

              <div className="checklist-progress-track">

                <div
                  className="checklist-progress-fill"
                  style={{
                    width: `${
                      progressMap[
                        selectedStudent.id
                      ]?.percentage || 0
                    }%`,
                  }}
                />

              </div>

            </div>


            {/* BODY */}

            <div className="checklist-body">

              {requirements.length ===
              0 ? (

                <div className="empty-checklist">

                  <strong>
                    No activities available
                  </strong>

                  <span>
                    Create an activity
                    from Manage Activity.
                  </span>

                </div>

              ) : (

                activityGroups.map(
                  (group) => (

                    <div
                      key={
                        group.week
                      }
                      className="week-section"
                    >

                      <div className="week-header">

                        <div>

                          <span>
                            ACTIVITY WEEK
                          </span>

                          <h3>
                            {
                              group.label
                            }
                          </h3>

                        </div>

                        <span className="week-count">
                          {
                            group.items
                              .length
                          }{' '}

                          {group.items
                            .length === 1
                            ? 'activity'
                            : 'activities'}
                        </span>

                      </div>


                      <div className="checklist-items">

                        {group.items.map(
                          (
                            requirement
                          ) => {

                            const existing =
                              getStudentActivity(
                                selectedStudent.id,
                                requirement.id
                              )

                            const completed =
                              existing?.completed ===
                              true

                            return (

                              <div
                                key={
                                  requirement.id
                                }
                                className={`checklist-item ${
                                  completed
                                    ? 'is-completed'
                                    : ''
                                }`}
                              >

                                <label className="check-item-label">

                                  <input
                                    type="checkbox"
                                    checked={
                                      completed
                                    }
                                    disabled={
                                      savingActivityId ===
                                      requirement.id
                                    }
                                    onChange={() =>
                                      toggleActivity(
                                        selectedStudent.id,
                                        requirement.id,
                                        completed
                                      )
                                    }
                                  />

                                  <span className="custom-checkbox" />

                                  <span className="check-item-text">

                                    <strong>
                                      {
                                        requirement.label
                                      }
                                    </strong>

                                    {requirement.code && (
                                      <small>
                                        {
                                          requirement.code
                                        }
                                      </small>
                                    )}

                                  </span>

                                </label>


                                <input
                                  type="text"
                                  className="check-item-note"
                                  placeholder="Add a note..."
                                  defaultValue={
                                    existing?.note ||
                                    ''
                                  }
                                  onBlur={(
                                    event
                                  ) =>
                                    saveNote(
                                      selectedStudent.id,
                                      requirement.id,
                                      event
                                        .target
                                        .value
                                    )
                                  }
                                />

                              </div>

                            )
                          }
                        )}

                      </div>

                    </div>

                  )
                )

              )}

            </div>


            <div className="modal-footer">

              <button
                type="button"
                className="activity-secondary-button"
                onClick={
                  closeChecklist
                }
              >
                Close
              </button>

            </div>

          </div>

        </div>

      )}


      {/* ======================================================
          MANAGE ACTIVITY MODAL
      ======================================================= */}

      {showManageActivity && (

        <div
          className="activity-modal-overlay"
          onMouseDown={(event) => {
            if (
              event.target ===
              event.currentTarget
            ) {
              closeManageActivity()
            }
          }}
        >

          <div
            className="manage-activity-modal"
            onMouseDown={(event) =>
              event.stopPropagation()
            }
          >

            <div className="modal-header">

              <div>

                <span className="activity-eyebrow">
                  ACTIVITY MANAGEMENT
                </span>

                <h2>
                  Manage Activity
                </h2>

                <p>
                  Add, edit, or delete
                  checklist activities.
                </p>

              </div>


              <button
                type="button"
                className="modal-close"
                onClick={
                  closeManageActivity
                }
              >
                ×
              </button>

            </div>


            <div className="manage-activity-toolbar">

              <div>

                <strong>
                  Activity List
                </strong>

                <span>
                  {totalActivities}{' '}
                  {totalActivities ===
                  1
                    ? 'activity'
                    : 'activities'}
                </span>

              </div>


              <button
                type="button"
                className="activity-primary-button"
                onClick={
                  openAddActivity
                }
              >
                <span className="button-plus">
                  +
                </span>

                Add Activity
              </button>

            </div>


            {requirements.length ===
            0 ? (

              <div className="manage-empty">

                <div className="manage-empty-icon">
                  +
                </div>

                <strong>
                  No activities yet
                </strong>

                <span>
                  Create the first activity
                  for the current semester.
                </span>

                <button
                  type="button"
                  className="activity-primary-button"
                  onClick={
                    openAddActivity
                  }
                >
                  + Add Activity
                </button>

              </div>

            ) : (

              <div className="manage-activity-list">

                {activityGroups.map(
                  (group) => (

                    <div
                      key={
                        group.week
                      }
                      className="manage-week"
                    >

                      <div className="manage-week-header">

                        <div>

                          <span>
                            ACTIVITY WEEK
                          </span>

                          <strong>
                            {
                              group.label
                            }
                          </strong>

                        </div>

                        <span>
                          {
                            group.items
                              .length
                          }{' '}

                          {group.items
                            .length === 1
                            ? 'activity'
                            : 'activities'}
                        </span>

                      </div>


                      {group.items.map(
                        (
                          requirement,
                          index
                        ) => (

                          <div
                            key={
                              requirement.id
                            }
                            className="manage-activity-row"
                          >

                            <div className="manage-number">
                              {String(
                                index + 1
                              ).padStart(
                                2,
                                '0'
                              )}
                            </div>


                            <div className="manage-activity-info">

                              <strong>
                                {
                                  requirement.label
                                }
                              </strong>

                              <div>

                                {requirement.code && (
                                  <span>
                                    {
                                      requirement.code
                                    }
                                  </span>
                                )}

                                <span>
                                  Week{' '}
                                  {
                                    requirement.week ??
                                    '—'
                                  }
                                </span>

                              </div>

                            </div>


                            <div className="manage-activity-actions">

                              <button
                                type="button"
                                className="activity-edit-button"
                                onClick={() =>
                                  openEditActivity(
                                    requirement
                                  )
                                }
                              >
                                Edit
                              </button>

                              <button
                                type="button"
                                className="activity-delete-button"
                                disabled={
                                  deletingActivityId ===
                                  requirement.id
                                }
                                onClick={() =>
                                  openDeleteActivity(
                                    requirement
                                  )
                                }
                              >
                                {deletingActivityId ===
                                requirement.id
                                  ? 'Deleting...'
                                  : 'Delete'}
                              </button>

                            </div>

                          </div>

                        )
                      )}

                    </div>

                  )
                )}

              </div>

            )}


            <div className="modal-footer">

              <button
                type="button"
                className="activity-secondary-button"
                onClick={
                  closeManageActivity
                }
              >
                Close
              </button>

            </div>

          </div>

        </div>

      )}


      {/* ======================================================
          ADD / EDIT ACTIVITY MODAL
      ======================================================= */}

      {showActivityForm && (

        <div
          className="activity-modal-overlay activity-form-overlay"
          onMouseDown={(event) => {
            if (
              event.target ===
              event.currentTarget
            ) {
              closeActivityForm()
            }
          }}
        >

          <div
            className="activity-form-modal"
            onMouseDown={(event) =>
              event.stopPropagation()
            }
          >

            <div className="modal-header">

              <div>

                <span className="activity-eyebrow">
                  {editingActivity
                    ? 'EDIT ACTIVITY'
                    : 'NEW ACTIVITY'}
                </span>

                <h2>
                  {editingActivity
                    ? 'Edit Activity'
                    : 'Add Activity'}
                </h2>

                <p>
                  {editingActivity
                    ? 'Update the activity details.'
                    : 'Create a new student checklist activity.'}
                </p>

              </div>


              <button
                type="button"
                className="modal-close"
                disabled={
                  savingActivity
                }
                onClick={
                  closeActivityForm
                }
              >
                ×
              </button>

            </div>


            <form
              className="activity-form"
              onSubmit={
                saveActivity
              }
            >

              <div className="form-grid">

                <label className="form-field form-field-wide">

                  <span>
                    Activity Name *
                  </span>

                  <input
                    type="text"
                    required
                    autoFocus
                    value={
                      activityForm.name
                    }
                    placeholder="Activity name"
                    onChange={(
                      event
                    ) =>
                      setActivityForm(
                        (current) => ({
                          ...current,
                          name:
                            event
                              .target
                              .value,
                        })
                      )
                    }
                  />

                </label>


                <label className="form-field">

                  <span>
                    Activity Week *
                  </span>

                  <select
                    value={
                      activityForm.week
                    }
                    onChange={(
                      event
                    ) =>
                      setActivityForm(
                        (current) => ({
                          ...current,
                          week:
                            event
                              .target
                              .value,
                        })
                      )
                    }
                  >

                    <option value="0">
                      General
                    </option>

                    {Array.from(
                      {
                        length: 16,
                      },
                      (
                        _,
                        index
                      ) => (
                        <option
                          key={
                            index + 1
                          }
                          value={
                            index + 1
                          }
                        >
                          Week{' '}
                          {index + 1}
                        </option>
                      )
                    )}

                  </select>

                </label>


                <label className="form-field">

                  <span>
                    Activity Code
                  </span>

                  <input
                    type="text"
                    value={
                      activityForm.code
                    }
                    placeholder="Optional"
                    onChange={(
                      event
                    ) =>
                      setActivityForm(
                        (current) => ({
                          ...current,
                          code:
                            event
                              .target
                              .value,
                        })
                      )
                    }
                  />

                </label>

              </div>


              <div className="activity-form-footer">

                <button
                  type="button"
                  className="activity-secondary-button"
                  disabled={
                    savingActivity
                  }
                  onClick={
                    closeActivityForm
                  }
                >
                  Cancel
                </button>


                <button
                  type="submit"
                  className="activity-primary-button"
                  disabled={
                    savingActivity
                  }
                >
                  {savingActivity
                    ? 'Saving...'
                    : editingActivity
                      ? 'Save Changes'
                      : 'Add Activity'}
                </button>

              </div>

            </form>

          </div>

        </div>

      )}


      {/* ======================================================
          DELETE CONFIRMATION MODAL
      ======================================================= */}

      {activityToDelete && (

        <div
          className="activity-modal-overlay delete-overlay"
          onMouseDown={(event) => {
            if (
              event.target ===
              event.currentTarget
            ) {
              closeDeleteActivity()
            }
          }}
        >

          <div
            className="delete-modal"
            onMouseDown={(event) =>
              event.stopPropagation()
            }
          >

            <div className="delete-modal-header">

              <div>

                <span className="activity-eyebrow">
                  DELETE ACTIVITY
                </span>

                <h2>
                  Delete Activity?
                </h2>

              </div>


              <button
                type="button"
                className="modal-close"
                onClick={
                  closeDeleteActivity
                }
              >
                ×
              </button>

            </div>


            <div className="delete-modal-body">

              <div className="delete-activity-preview">

                <strong>
                  {
                    activityToDelete.label
                  }
                </strong>

                <span>

                  Week{' '}
                  {
                    activityToDelete.week ??
                    '—'
                  }

                  {activityToDelete.code &&
                    ` · ${activityToDelete.code}`}

                </span>

              </div>


              <p>
                Are you sure you want to
                delete this activity?
              </p>

              <p className="delete-warning-text">
                This will also remove the
                checklist records associated
                with this activity for all
                students. This action cannot
                be undone.
              </p>

            </div>


            <div className="delete-modal-footer">

              <button
                type="button"
                className="activity-secondary-button"
                disabled={
                  Boolean(
                    deletingActivityId
                  )
                }
                onClick={
                  closeDeleteActivity
                }
              >
                Cancel
              </button>


              <button
                type="button"
                className="delete-confirm-button"
                disabled={
                  Boolean(
                    deletingActivityId
                  )
                }
                onClick={
                  confirmDeleteActivity
                }
              >
                {deletingActivityId
                  ? 'Deleting...'
                  : 'Delete Activity'}
              </button>

            </div>

          </div>

        </div>

      )}

    </div>
  )
}

export default ActivityTracker