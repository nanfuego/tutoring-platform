import { Routes, Route } from 'react-router-dom'
import StudentStatus from './pages/StudentStatus'
import AdminLogin from './pages/AdminLogin'
import AdminDashboard from './pages/AdminDashboard'
import StudentDetail from './pages/StudentDetail'
import PaymentTracker from './pages/PaymentTracker'
import ActivityTracker from './pages/ActivityTracker'
import AdminShell from './components/AdminShell'
import ProtectedRoute from './components/ProtectedRoute'

function AdminPage({ children }) {
  return (
    <ProtectedRoute>
      <AdminShell>{children}</AdminShell>
    </ProtectedRoute>
  )
}

function App() {
  return (
    <Routes>
      <Route path="/" element={<h1>Tutoring Platform</h1>} />
      <Route path="/status/:slug" element={<StudentStatus />} />
      <Route path="/admin/login" element={<AdminLogin />} />

      <Route
        path="/admin"
        element={
          <AdminPage>
            <AdminDashboard />
          </AdminPage>
        }
      />

      <Route
        path="/admin/students/:id"
        element={
          <AdminPage>
            <StudentDetail />
          </AdminPage>
        }
      />

      <Route
        path="/admin/activity"
        element={
          <AdminPage>
            <ActivityTracker />
          </AdminPage>
        }
      />

      <Route
        path="/admin/payments"
        element={
          <AdminPage>
            <PaymentTracker />
          </AdminPage>
        }
      />
    </Routes>
  )
}

export default App
